const teamsInputs = document.querySelectorAll('#teams input');
const matchesDiv = document.getElementById('matches');
const tableBody = document.querySelector('#table tbody');

const matchups = [
  [0,1], [2,3],
  [0,2], [1,3],
  [0,3], [1,2]
];

function saveData() {
  const data = {
    teams: Array.from(teamsInputs).map(i => i.value),
    scores: Array.from(document.querySelectorAll('.score')).map(s => s.value)
  };
  localStorage.setItem('miniAmericanoData', JSON.stringify(data));
}

function loadData() {
  const saved = localStorage.getItem('miniAmericanoData');
  if (!saved) return;
  const data = JSON.parse(saved);
  teamsInputs.forEach((i, idx) => i.value = data.teams[idx] || '');
  document.querySelectorAll('.score').forEach((s, idx) => s.value = data.scores[idx] || '');
}

function buildMatches() {
  matchesDiv.innerHTML = '';
  matchups.forEach(([a,b], i) => {
    const div = document.createElement('div');
    div.innerHTML = `Match ${i+1}: <br>${teamsInputs[a].value||'Pareja '+(a+1)} 
      <input class="score" type="number" min="0" max="7"> vs 
      <input class="score" type="number" min="0" max="7"> 
      ${teamsInputs[b].value||'Pareja '+(b+1)}`;
    matchesDiv.appendChild(div);
  });
  document.querySelectorAll('.score').forEach(s => s.addEventListener('input', saveData));
}

function calculate() {
  const teams = Array.from(teamsInputs).map(i => i.value || 'Pareja ' + (Array.from(teamsInputs).indexOf(i)+1));
  const stats = teams.map(() => ({PJ:0, GF:0, GC:0, Pts:0}));
  const scores = Array.from(document.querySelectorAll('.score')).map(s => parseInt(s.value)||0);
  for (let i=0; i<matchups.length; i++) {
    const [a,b] = matchups[i];
    const g1 = scores[i*2], g2 = scores[i*2+1];
    if (isNaN(g1)||isNaN(g2)) continue;
    stats[a].PJ++; stats[b].PJ++;
    stats[a].GF+=g1; stats[a].GC+=g2;
    stats[b].GF+=g2; stats[b].GC+=g1;
    if (g1>g2) stats[a].Pts+=g1; else stats[b].Pts+=g2;
  }
  tableBody.innerHTML = '';
  stats.forEach((s,i)=>{
    const dif = s.GF - s.GC;
    const tr = `<tr><td>${i+1}</td><td>${teams[i]}</td><td>${s.PJ}</td><td>${s.GF}</td><td>${s.GC}</td><td>${dif}</td><td>${s.Pts}</td></tr>`;
    tableBody.innerHTML += tr;
  });
}

document.getElementById('recalculate').onclick = calculate;
document.getElementById('reset').onclick = ()=>{localStorage.clear();location.reload();};
document.getElementById('clear').onclick = ()=>{localStorage.removeItem('miniAmericanoData');location.reload();};
window.addEventListener('load', ()=>{buildMatches();loadData();});
teamsInputs.forEach(i=>i.addEventListener('input', buildMatches));